/* Design: Editorial Tecnológica — composição assimétrica, contraste marfim/preto, azul cobalto como assinatura, mono para metadados e interações rápidas. */

import { useState } from "react";
import {
  ArrowUpRight,
  Github,
  Linkedin,
  Menu,
  MoveDownRight,
  Sparkles,
  X,
} from "lucide-react";

const projects = [
  {
    number: "01",
    title: "Atlas",
    category: "Data product",
    description:
      "Painel de inteligência operacional que transforma métricas dispersas em decisões claras para times em movimento.",
    stack: ["React", "TypeScript", "Charts"],
    image: "/manus-storage/project-atlas_06d3a8b3.jpg",
    accent: "cobalt",
  },
  {
    number: "02",
    title: "Orbit",
    category: "Mobile experience",
    description:
      "Uma experiência mobile leve para organizar rotinas, visualizar progresso e manter o foco no que importa.",
    stack: ["React Native", "Node.js", "UX"],
    image: "/manus-storage/project-orbit_a3a5dca5.jpg",
    accent: "lime",
  },
  {
    number: "03",
    title: "Forma",
    category: "Design system",
    description:
      "Sistema de componentes que aproxima design e engenharia e devolve consistência para cada nova entrega.",
    stack: ["Tokens", "Storybook", "A11y"],
    image: null,
    accent: "ink",
  },
];

const skills = [
  "Front-end architecture",
  "Product interfaces",
  "Design systems",
  "APIs & integrations",
  "Performance",
  "Accessibility",
];

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  const closeMenu = () => setMenuOpen(false);

  return (
    <main className="site-shell">
      <header className="site-header">
        <a className="brand-lockup" href="#top" aria-label="Alex Silva, início">
          <span className="brand-mark" aria-hidden="true">
            <span />
          </span>
          <span className="brand-name">alexsilva<span>.dev</span></span>
        </a>

        <nav className={`main-nav ${menuOpen ? "is-open" : ""}`} aria-label="Navegação principal">
          <a href="#projetos" onClick={closeMenu}>Projetos</a>
          <a href="#sobre" onClick={closeMenu}>Sobre</a>
          <a href="#contato" onClick={closeMenu}>Contato</a>
        </nav>

        <div className="header-actions">
          <a className="availability" href="#contato">
            <span className="availability-dot" /> Disponível para projetos
          </a>
          <button className="menu-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? "Fechar menu" : "Abrir menu"} aria-expanded={menuOpen}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </header>

      <div id="top" className="hero-section">
        <div className="hero-copy">
          <div className="eyebrow"><span>01 / Perfil</span><span className="eyebrow-line" /></div>
          <p className="hero-kicker">Desenvolvedor Full Stack<br />& Designer de Produtos Digitais</p>
          <h1>Eu construo<br /><em>ideias úteis.</em></h1>
          <p className="hero-intro">Código com intenção, interfaces com clareza e produtos digitais que fazem sentido para quem usa.</p>
          <div className="hero-cta-row">
            <a className="button-primary" href="#projetos">Explorar projetos <ArrowUpRight size={17} /></a>
            <a className="text-link" href="#sobre">Como eu trabalho <MoveDownRight size={16} /></a>
          </div>
        </div>

        <div className="hero-visual-wrap">
          <div className="hero-visual">
            <img src="/manus-storage/dev-hero_13c0ea60.jpg" alt="Composição abstrata editorial com formas geométricas e linhas de interface" />
            <div className="hero-visual-label">Selected work<br /><strong>2021—2026</strong></div>
            <div className="hero-visual-index">A / 01</div>
          </div>
          <div className="hero-caption"><span>01</span><span>Software, but thoughtful.</span><span>Scroll to explore ↓</span></div>
        </div>
      </div>

      <section className="signal-strip" aria-label="Resumo profissional">
        <div><span className="mono-label">BASE</span><strong>São Paulo, BR</strong></div>
        <div><span className="mono-label">FOCO</span><strong>Web & mobile products</strong></div>
        <div><span className="mono-label">STATUS</span><strong><span className="status-pulse" /> Aceitando novos projetos</strong></div>
        <div><span className="mono-label">EXPERIÊNCIA</span><strong>6+ anos construindo</strong></div>
      </section>

      <section id="projetos" className="projects-section">
        <div className="section-heading">
          <div className="eyebrow"><span>02 / Projetos selecionados</span><span className="eyebrow-line" /></div>
          <div className="heading-side-note">Alguns problemas que tive<br />o prazer de resolver.</div>
        </div>
        <div className="project-list">
          {projects.map((project) => (
            <article className={`project-card accent-${project.accent}`} key={project.number}>
              <div className="project-meta"><span>{project.number}</span><span>{project.category}</span></div>
              <div className="project-content">
                <div className="project-info">
                  <h2>{project.title}<sup>↗</sup></h2>
                  <p>{project.description}</p>
                  <div className="stack-list">{project.stack.map((item) => <span key={item}>{item}</span>)}</div>
                  <a className="project-link" href="#contato">Ver estudo de caso <ArrowUpRight size={16} /></a>
                </div>
                <div className={`project-image ${project.image ? "has-image" : "type-only"}`}>
                  {project.image ? <img src={project.image} alt={`Visual do projeto ${project.title}`} /> : <div className="forma-art"><span>F</span><span>+</span><span>∕</span></div>}
                  <span className="corner-mark corner-tl">⌜</span><span className="corner-mark corner-br">⌟</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="sobre" className="about-section">
        <div className="about-stamp"><Sparkles size={17} /><span>Sobre<br />o processo</span></div>
        <div className="about-main">
          <div className="eyebrow"><span>03 / Sobre</span><span className="eyebrow-line" /></div>
          <h2>Entre o problema<br />e a <em>possibilidade.</em></h2>
          <p className="about-lead">A melhor parte de construir software é descobrir o que ele pode destravar. Eu trabalho na interseção entre engenharia, produto e design para transformar complexidade em experiências que parecem simples.</p>
          <div className="about-grid">
            <div className="about-column"><span className="mono-label">O QUE EU FAÇO</span><p>Entro cedo na conversa, faço as perguntas difíceis e saio com uma solução que consegue chegar até as pessoas.</p></div>
            <div className="about-column"><span className="mono-label">COMO EU PENSO</span><p>Começo pelo contexto, prototipo antes de polir e trato performance e acessibilidade como parte do produto.</p></div>
          </div>
        </div>
        <div className="skills-panel">
          <span className="mono-label">AREAS OF PRACTICE</span>
          <ul>{skills.map((skill, index) => <li key={skill}><span>0{index + 1}</span>{skill}<ArrowUpRight size={14} /></li>)}</ul>
        </div>
      </section>

      <section id="contato" className="contact-section">
        <div className="contact-topline"><span>04 / Vamos conversar</span><span>Open for the right challenge</span></div>
        <div className="contact-content">
          <div><h2>Tem uma ideia<br />na cabeça?</h2><p>Vamos transformar o ponto de interrogação em uma primeira versão.</p></div>
          <a className="contact-email" href="mailto:hello@alexsilva.dev">hello@alexsilva.dev <ArrowUpRight size={28} /></a>
        </div>
        <div className="contact-footer"><span>© 2026 Alex Silva</span><div className="socials"><a href="https://github.com" target="_blank" rel="noreferrer" aria-label="GitHub"><Github size={17} /></a><a href="https://linkedin.com" target="_blank" rel="noreferrer" aria-label="LinkedIn"><Linkedin size={17} /></a></div><span>Built with curiosity + code</span></div>
      </section>
    </main>
  );
}
